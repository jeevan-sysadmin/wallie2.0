// For Firebase JS SDK v7.20.0 and later, measurementId is optional
const firebaseConfig = {
    apiKey: "AIzaSyDHfc4mcUjIC3pLHmIHANE-hMT2y2_D8ys",
    authDomain: "walle-ai-71c09.firebaseapp.com",
    databaseURL: "https://walle-ai-71c09-default-rtdb.firebaseio.com",
    projectId: "walle-ai-71c09",
    storageBucket: "walle-ai-71c09.appspot.com",
    messagingSenderId: "284706423734",
    appId: "1:284706423734:web:9071cde486637d05ff3717",
    measurementId: "G-0W8R65EDY0"
  };