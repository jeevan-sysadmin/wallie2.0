// Component Imports
import PropertyListing from '@views/pages/wizard-examples/property-listing'

const PropertyListingPage = () => {
  return <PropertyListing />
}

export default PropertyListingPage
