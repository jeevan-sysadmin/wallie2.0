// Component Imports
import CreateDeal from '@views/pages/wizard-examples/create-deal'

const CreateDealPage = () => {
  return <CreateDeal />
}

export default CreateDealPage
