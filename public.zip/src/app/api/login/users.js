// ** Fake user data and data type
// =============== Fake Data ============================
export const users = [
  {
    id: 1,
    name: 'John Doe',
    password: 'admin',
    email: 'admin@wallie.ai',
    image: '/images/avatars/1.png'
  },
  {
    id: 2,
    name: 'Jeevan Larosh',
    password: 'client',
    email: 'client@wallie.ai',
    image: '/images/avatars/1.png'
  }
]
